package com.example.midtermapi001;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MidtermApi001ApplicationTests {

    @Test
    void contextLoads() {
    }

}
